package exercise;

public class Printer {
	void println(int n) {
		System.out.println(n);
	}

	void println(boolean n) {
		System.out.println(n);
	}

	void println(double n) {
		System.out.println(n);
	}

	void println(String n) {
		System.out.println(n);
	}
}
