package exercise;

public class Printer2 {
	static void println(int n) {
		System.out.println(n);
	}

	static void println(boolean n) {
		System.out.println(n);
	}

	static void println(double n) {
		System.out.println(n);
	}

	static void println(String n) {
		System.out.println(n);
	}

}
