package exercise;

public class PrintExam {
	public static void main(String[] args) {
		Printer print = new Printer();
		print.println(10);
		print.println(true);
		print.println(5.7);
		print.println("ȫ�浿");
	}
}
