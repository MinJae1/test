package exercise;

//Exe13 & Exe14
public class Member {
	String name;
	String id;
	String password;
	int age;

	public Member(String name, String id) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.id = id;
	}
}
