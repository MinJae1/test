package ex07;

public class NoExistIDException extends Exception {
	public NoExistIDException() {
		// TODO Auto-generated constructor stub
	}

	public NoExistIDException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
