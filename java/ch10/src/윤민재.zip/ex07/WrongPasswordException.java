package ex07;

public class WrongPasswordException extends Exception{
	public WrongPasswordException() {
		// TODO Auto-generated constructor stub
	}

	public WrongPasswordException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
