package excercise;

public class problem03 {
	public static void main(String[] args) {
		int score = 85;
		String result = (!(score > 90)) ? "��" : "��";

		System.out.println(result);
	}
}
