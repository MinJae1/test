package app;

public class BalanceInsufficientException extends Exception {
	public BalanceInsufficientException() {
		// TODO Auto-generated constructor stub
	}

	public BalanceInsufficientException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
//		System.out.println(msg);
	}
}
