package ex05;

public interface Action {
	void work();
}
