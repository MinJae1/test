package ex04;

public class MtSqlDao implements DataAccessObject {

	@Override
	public void select() {
		// TODO Auto-generated method stub
		System.out.println("MtSql DB search");
	}

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		System.out.println("MtSql DB insert");
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("MtSql DB update");
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		System.out.println("MtSql DB delete");
	}

}
