package ex03;

public class Cat implements Soundable {

	@Override
	public String Sound() {
		// TODO Auto-generated method stub
//		System.out.println("Miaow");
		return "Miaow";
	}

}
