package ex03;

public interface Soundable {
	String Sound();
}
