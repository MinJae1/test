package ex03;

public class Dog implements Soundable {

	@Override
	public String Sound() {
		// TODO Auto-generated method stub
//		System.out.println("Bow Wow");
		return "Bow Wow";
	}

}
