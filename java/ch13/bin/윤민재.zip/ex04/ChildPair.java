package ex04;

public class ChildPair<K, V> extends Pair<K, V> {

	public ChildPair(K key, V value) {
		super(key, value);
		// TODO Auto-generated constructor stub
	}

}
