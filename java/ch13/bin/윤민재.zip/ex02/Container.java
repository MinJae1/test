package ex02;

public class Container<T> {

	T name;

	public void set(T name) {
		// TODO Auto-generated method stub
		this.name = name;
	}

	public T get() {
		// TODO Auto-generated method stub
		return name;
	}

}
