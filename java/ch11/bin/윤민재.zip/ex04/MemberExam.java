package ex04;

public class MemberExam {
	public static void main(String[] args) {
		Member obj1 = new Member("blue", "Lee Pa Ran");
		System.out.println(obj1);
	}
}
