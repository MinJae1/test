package ex05;

public class Parent {
	public String name;

	public Parent(String name) {
		// TODO Auto-generated constructor stub
		this.name = name;
	}
}
