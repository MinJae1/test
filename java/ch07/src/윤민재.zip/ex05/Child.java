package ex05;

public class Child extends Parent {
	private int stNo;

	public Child(String name, int stNo) {
		super(name);
		this.stNo = stNo;
		// TODO Auto-generated constructor stub
	}
}
