package ex07;

public class SnowTire extends Tire {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("snow Tire");
	}

}
