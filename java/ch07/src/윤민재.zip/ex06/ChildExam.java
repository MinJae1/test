package ex06;

public class ChildExam {
	public static void main(String[] args) {
		Child child = new Child();
	}
}
